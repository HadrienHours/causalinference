#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv []){
        int t;
        t=atoi(argv[1]);
        usleep(t);
        return 0;
}

void SleepMs(int ms) {
usleep(ms*1000); //convert to microseconds
return;
}

